module.exports = {
  "botName": "Lyons Bot",
  "owner": [
    "6287762207808",
    "6285191985603" // GANTI BEBAS
  ],
  "superOwner": [
    "6287762207808", // GANTI AJA
    "6285191985603" // GANTI AJA
  ],
  "engginerBot": [
    "6287762207808" // BIARIN INI NO ENGGINER
  ],
  "autoAddBotNumber": true,
  "prefix": ".",
  "publicMode": true,
  "sessionName": "session",
  "footer": "© Created By LYONS-XD", // GANTI NAMA KALIAN
  "packname": "-",
  "author": "-",
  "version": "1.5.0",
  "commands": {
    "superowner": [
      "public",
      "asisten",
      "addowner",
      "deleteowner",
      "self",
      "setname",
      "setprefix",
      "setbio",
      "autobio",
      "setbiodelay",
      "bug",
      "report",
      "setbioformat"
    ],
    "owner": [
      "pushkontak-v1",
      "pushkontak-v2",
      "pushkontak-v3",
      "pushkontak-v4",
      "savekontak-v1",
      "savekontak-v2",
      "jpm",
      "listidgc",
      "hidetag",
      "antilink",
      "tagall",
      "cekgc"
    ],
    "admin": [
      "promote",
      "demote",
      "antilink",
      "gc",
      "leave",
      "welcome",
      "resetlinkgc",
      "tagall",
      "kick"
    ]
  },
  "features": {
    "antilink": {
      "enabled": true,
      "version": "v1",
      "lastVersion": "v1"
    },
    "msgVerif": {
      "enabled": true,
      "caption": "WhatsApp"
    },
    "msgAds": {
      "enabled": true,
      "showAttribution": true,
      "renderLargerThumbnail": false,
      "thumbnailPath": "lyons/media/thumb.jpg",
      "mediaType": 1,
      "showAdAttribution": true,
      "jpegThumbnail": "lyons/media/thumb.jpg"
    },
    "msgForwarded": {
      "enabled": true,
      "score": 999999
    },
    "welcome": {
      "enabled": true
    },
    "leave": {
      "enabled": true
    },
    "aiAssistant": {
      "enabled": true,
      "maxHistory": 55,
      "version": "v1",
      "v1": {
        "enabled": false,
        "defaultModel": "blackbox",
        "availableModels": [
          "gpt",
          "claude",
          "bagoodex",
          "duckduckgo",
          "blackbox"
        ]
      }
    },
    "sticker": {
      "packname": "aloha", // GANTI PACK STIKER
      "author": "lyonsajh", // GANTI AUTHOR STIKER
      "categories": [
        "STICKER"
      ],
      "quality": 70,
      "background": "transparent"
    },
    "session": {
      "folderName": "./sessions",
      "sessionName": "bot-session",
      "saveCredentials": true,
      "maxRetries": 10,
      "retryInterval": 3000,
      "keepAliveInterval": 10000
    },
    "HFToken": "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",
    "presence": {
      "enabled": true,
      "commandProcessing": "recording",
      "delay": {
        "default": 1000,
        "image": 1000,
        "video": 1000,
        "audio": 1000,
        "sticker": 1000
      }
    },
    "autoBio": {
      "enabled": true
    }
  }
}