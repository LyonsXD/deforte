const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion
} = require("@whiskeysockets/baileys");
const pino = require("pino");
const fs = require("fs");
const chalk = require("chalk");
const path = require("path");
const settings = require("./lyons/settings/config.js");
const { CommandHandler } = require("./lyons-bot_4107.js");
const readline = require("readline");
const { StickerAICommand } = require('./lyons/module/lyons-bot_2534.js');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const sessionDir = "./session";
let sock = null;

const MESSAGES = {
    CONNECTED: `*ᴊᴏɪɴ ᴄʜᴀɴɴᴇʟ ɪɴꜰᴏ ꜱᴄʀɪᴘᴛ ʙᴏᴛ ᴡᴀ ɢʀᴀᴛɪꜱ:*\n` +
               `https://whatsapp.com/channel/0029VatcVey7NoZwa7gBFR2o\n\n` +
               `*ꜱᴜʙꜱᴄʀɪʙᴇ ʏᴏᴜᴛᴜʙᴇ:*\n` +
               `https://youtube.com/@ly-team?si=DYrB03D1QJO3JZa\n\n` +
               `> *ɴᴏᴛᴇ:* ꜱᴄʀɪᴘᴛ ɪɴɪ 100% ɢʀᴀᴛɪꜱ, ᴊᴀɴɢᴀɴ ᴅɪᴊᴜᴀʟ, ꜱʜᴀʀᴇ?? ᴡᴀᴊɪʙ ᴄʀᴇᴅɪᴛ!!`
};

async function connectToWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestBaileysVersion();
    
    sock = makeWASocket({
        version,
        logger: pino({ level: "silent" }),
        printQRInTerminal: false,
        auth: state,
        browser: ["Linux", "Chrome", "116.0.5845.97"],
        connectTimeoutMs: 60_000,
        defaultQueryTimeoutMs: 30_000,
        keepAliveIntervalMs: 15000,
        emitOwnEvents: true,
        markOnlineOnConnect: true,
        getMessage: async key => {
            return { conversation: '' }
        }
    });

    const commandHandler = new CommandHandler(sock, settings);

    if (settings.features.autoBio.enabled) {
        for (const [cmd, moduleInfo] of commandHandler.modules.entries()) {
            if (moduleInfo.instance && 
                moduleInfo.instance.commands && 
                moduleInfo.instance.commands.includes('owner')) {
                    moduleInfo.instance.startAutoBio();
                    console.log('Auto bio started!');
                    break;
            }
        }
    }

    sock.ev.on("creds.update", saveCreds);

    sock.ev.on("messages.upsert", async ({ messages, type }) => {
        try {
            if (type !== 'notify') return;
            
            const msg = messages[0];
            if (!msg) return;
            
            // Langsung proses command
            await commandHandler.handleCommand(msg);
            
        } catch (error) {
            console.error('Error in message handler:', error);
        }
    });

    sock.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect } = update;
        
        if (connection === "close") {
            const shouldReconnect = (lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut;
            
            if (shouldReconnect) {
                await clearBotCache();
                await new Promise(resolve => setTimeout(resolve, 1000));
                connectToWhatsApp();
            }
        }
        
        if (connection === "open") {
            const botNumber = sock.user.id.split(':')[0];
            const connectImage = fs.readFileSync('./lyons/media/connect.jpg');
            
            await sock.sendPresenceUpdate('recording', `${botNumber}@s.whatsapp.net`);
            await new Promise(resolve => setTimeout(resolve, 600));
            
            await sock.sendMessage(`${botNumber}@s.whatsapp.net`, {
                image: connectImage,
                caption: MESSAGES.CONNECTED,
                contextInfo: {
                    externalAdReply: {
                        title: "BOT TELAH TERKONEKSI",
                        body: "ꜱᴄʀɪᴘᴛ ʙʏ ʟʏ-ᴛᴇᴀᴍ",
                        mediaType: 1,
                        thumbnail: null,
                        renderLargerThumbnail: false,
                        showAdAttribution: true
                    }
                }
            });
            
            await sock.sendPresenceUpdate('paused', `${botNumber}@s.whatsapp.net`);
        }
    });

    if (!fs.existsSync(path.join(sessionDir, 'creds.json'))) {
        const phoneNumber = await new Promise(resolve => {
            rl.question('Masukkan nomor WhatsApp (628xxx): ', resolve);
        });
        
        const code = await sock.requestPairingCode(phoneNumber);
        console.log(`\nKode pairing: ${code}`);
        rl.close();
    }

    return sock;
}

process.on('uncaughtException', console.error);
process.on('SIGINT', async () => {
    if (sock) await sock.end();
    process.exit();
});

if (!fs.existsSync(sessionDir)) {
    fs.mkdirSync(sessionDir, { recursive: true });
}

connectToWhatsApp();

// Fungsi untuk clear cache
async function clearBotCache() {
    try {
        const cachePaths = [
            path.join(sessionDir, 'cache'),
            path.join(sessionDir, 'tmp'),
            path.join(sessionDir, '.temp')
        ];

        for (const cachePath of cachePaths) {
            if (fs.existsSync(cachePath)) {
                const files = fs.readdirSync(cachePath);
                for (const file of files) {
                    // Skip file penting
                    if (file === 'creds.json' || file === 'auth_info.json') continue;
                    
                    const filePath = path.join(cachePath, file);
                    const stats = fs.statSync(filePath);
                    
                    // Hapus file yang lebih dari 1 jam
                    if (Date.now() - stats.mtimeMs > 3600000) {
                        fs.unlinkSync(filePath);
                    }
                }
                console.log(`Cache dibersihkan: ${cachePath}`);
            }
        }
    } catch (err) {
        console.log('Gagal membersihkan cache:', err);
    }
}