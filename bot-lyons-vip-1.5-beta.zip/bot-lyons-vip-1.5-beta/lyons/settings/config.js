module.exports = {
  "botName": "LYONS XD BOT",
  "owner": [
    "6287762207808",
    "6285191985603"
  ],
  "superOwner": [
    "6287762207808",
    "6285191985603"
  ],
  "autoAddBotNumber": true,
  "prefix": ".",
  "publicMode": true,
  "sessionName": "session",
  "footer": "© Created By LYONS-XD",
  "packname": "-",
  "author": "-",
  "version": "1.5.0",
  "commands": {
    "superowner": [
      "public",
      "asisten",
      "self"
    ],
    "owner": [
      "pushkontak-v1",
      "pushkontak-v2",
      "pushkontak-v3",
      "pushkontak-v4",
      "savekontak-v1",
      "savekontak-v2",
      "jpm",
      "listidgc",
      "hidetag",
      "cekgc"
    ],
    "admin": [
      "promote",
      "demote",
      "antilink",
      "gc",
      "leave",
      "welcome",
      "resetlinkgc",
      "kick"
    ]
  },
  "features": {
    "msgVerif": {
      "enabled": true,
      "caption": "WhatsApp"
    },
    "msgAds": {
      "enabled": true,
      "showAttribution": true,
      "renderLargerThumbnail": false,
      "profileUrl": "https://wa.me/6287762207808",
      "youtubeUrl": "https://youtube.com/@ly-team?si=DYrB03D1QJO3JZa ",
      "thumbnailPath": "lyons/media/thumb.jpg",
      "mediaType": 1,
      "showAdAttribution": true,
      "jpegThumbnail": "lyons/media/thumb.jpg",
      "instagram": "",
      "youtube": "LYONS XD",
      "github": "github.com/lyteam-id"
    },
    "msgForwarded": {
      "enabled": true,
      "score": 999999
    },
    "welcome": {
      "enabled": true
    },
    "leave": {
      "enabled": true
    },
    "antilink": {
      "enabled": true
    },
    "aiAssistant": {
      "enabled": true,
      "maxHistory": 55,
      "version": "v1",
      "v1": {
        "enabled": true,
        "model": "claude-3.5-sonnet"
      },
      "adReply": {
        "title": "AI Assistant",
        "body": "Fann-LY",
        "mediaType": 1,
        "thumbnailPath": "./media/thumb.jpg",
        "renderLargerThumbnail": false,
        "showAttribution": true
      }
    },
    "sticker": {
      "packname": "STICKER",
      "author": "Lyons",
      "categories": [
        ""
      ],
      "quality": 70,
      "background": "transparent"
    },
    "session": {
      "folderName": "./sessions",
      "sessionName": "bot-session",
      "saveCredentials": true,
      "maxRetries": 10,
      "retryInterval": 3000,
      "keepAliveInterval": 10000
    },
    "HFToken": "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"
  }
}