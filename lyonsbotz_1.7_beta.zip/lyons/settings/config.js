module.exports = {
  "botName": "Lyons Bot",
  "owner": [
    "6287762207808",
    "6285191985603"
  ],
  "superOwner": [
    "6287762207808",
    "6285191985603"
  ],
  "engginerBot": [
    "6287762207808"
  ],
  "autoAddBotNumber": true,
  "prefix": ".",
  "publicMode": true,
  "sessionName": "session",
  "footer": "© Created By LYONS-XD",
  "packname": "-",
  "author": "-",
  "version": "1.5.0",
  "commands": {
    "superowner": [
      "public",
      "asisten",
      "addowner",
      "deleteowner",
      "self",
      "setname",
      "setprefix",
      "setbio",
      "autobio",
      "setbiodelay",
      "bug",
      "report",
      "setbioformat",
      "pushkontak",
      "pushkontakv1",
      "pushv1",
      "pushkontakv2",
      "pushv2",
      "pushkontakv3",
      "pushv3",
      "pushkontakv4",
      "pushv4",
      "savekontakv1",
      "savev1",
      "savekontakv2",
      "savev2",
      "jpm",
      "listidgc",
      "hidetag",
      "antilink",
      "tagall",
      "cekgc"
    ],
    "owner": [
      "pushkontak",
      "pushkontakv1",
      "pushv1",
      "pushkontakv2",
      "pushv2",
      "pushkontakv3",
      "pushv3",
      "pushkontakv4",
      "pushv4",
      "savekontakv1",
      "savev1",
      "savekontakv2",
      "savev2",
      "jpm",
      "listidgc",
      "hidetag",
      "antilink",
      "tagall",
      "cekgc"
    ],
    "admin": [
      "promote",
      "demote",
      "antilink",
      "gc",
      "leave",
      "welcome",
      "resetlinkgc",
      "tagall",
      "kick"
    ]
  },
  "features": {
    "antilink": {
      "enabled": true,
      "version": "v1",
      "lastVersion": "v1"
    },
    "msgVerif": {
      "enabled": true,
      "caption": "WhatsApp"
    },
    "msgAds": {
      "enabled": true,
      "showAttribution": true,
      "renderLargerThumbnail": false,
      "thumbnailPath": "lyons/media/thumb.jpg",
      "mediaType": 1,
      "showAdAttribution": true,
      "jpegThumbnail": "lyons/media/thumb.jpg"
    },
    "msgForwarded": {
      "enabled": true,
      "score": 999999
    },
    "welcome": {
      "enabled": true
    },
    "leave": {
      "enabled": true
    },
    "aiAssistant": {
      "enabled": true,
      "maxHistory": 55,
      "version": "v1",
      "v1": {
        "enabled": true,
        "defaultModel": "gpt",
        "availableModels": [
          "gpt",
          "claude",
          "bagoodex",
          "duckduckgo",
          "blackbox"
        ]
      }
    },
    "sticker": {
      "packname": "aloha",
      "author": "lyonsajh",
      "categories": [
        "STICKER"
      ],
      "quality": 70,
      "background": "transparent"
    },
    "session": {
      "folderName": "./sessions",
      "sessionName": "bot-session",
      "saveCredentials": true,
      "maxRetries": 10,
      "retryInterval": 3000,
      "keepAliveInterval": 10000
    },
    "HFToken": "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",
    "presence": {
      "enabled": true,
      "commandProcessing": "recording",
      "delay": {
        "default": 1000,
        "image": 1000,
        "video": 1000,
        "audio": 1000,
        "sticker": 1000
      }
    },
    "autoBio": {
      "enabled": true
    }
  }
}